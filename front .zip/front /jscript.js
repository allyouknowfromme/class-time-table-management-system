function disappear()
{
var t= document.getElementById("dcode").value="";

t.style="colord:red";
}


function chngclr()
{
var t= document.getElementById("dcode").value;

t.style ="color:blue";
}


function disappear1()
{
var t= document.getElementById("day").value="";


t.style="colord:red";
}



function disappear2()
{
var t= document.getElementById("classnum").value="";

t.style="colord:red";
}



function disappear3()
{

var t= document.getElementById("sem").value="";

t.style="colord:red";
}

function disappear4()
{

var t= document.getElementById("staffname").value="";

t.style="colord:red";
}



