import java.sql.*;
import javax.sql.*;
import java.util.*;
public class timetable

{
public static void faculty(Connection con,Scanner scan) throws Exception
{
System.out.println("Enter faculty department number  :");
String dcode;
dcode=scan.next();
dcode=dcode.trim();
dcode=dcode.toUpperCase();
Statement st= con.createStatement();
        ResultSet rs=st.executeQuery("SELECT fid,fname,rank,place FROM faculty WHERE dcode='"+dcode+"';");
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("faculty list: :");
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("id "+"\t"+" ||\t name    || \t rank   || \t place    || \t ");
System.out.println("-------------------------------------------------------------------------------------");
   
        while (rs.next())
        {
   
            System.out.print(rs.getString(1));
	    System.out.print("\t || \t");
	    System.out.print(rs.getString(2));
		System.out.print("\t || \t");

            System.out.print(rs.getInt(3));
	    System.out.print("\t || \t");
	    System.out.println(rs.getString(4));


          
        }
System.out.println("-------------------------------------------------------------------------------------");
       
         con.close();
     
    }













public static void TableClass(Connection con,Scanner scan) throws Exception
{
 System.out.println("enter the department code ");
					String str=scan.next();
					str= str.trim();
					str= str.toUpperCase();

 Statement st= con.createStatement();
ResultSet rs=st.executeQuery("SELECT c.cno,c.sem from department d,class c WHERE c.dcode = d.dcode and d.dcode='"+str+"';");
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("class room  :");
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("classno "+"\t"+" ||\t sem");
System.out.println("-------------------------------------------------------------------------------------");
   
        while (rs.next())
        {
   
            System.out.print(rs.getInt(1));
	    System.out.print("\t || \t");
	    System.out.println(rs.getInt("c.sem"));
        }
System.out.println("-------------------------------------------------------------------------------------");
       
   con.close();}











public static void TableDept(Connection con) throws Exception
{
Statement st= con.createStatement();
ResultSet rs=st.executeQuery("SELECT * from department;");
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("department list :");
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("dnum "+"\t"+" ||\tdname");
System.out.println("-------------------------------------------------------------------------------------");
   while (rs.next())
        {
   
            System.out.print(rs.getString(2));
	    System.out.print("\t || \t");
	    System.out.println(rs.getString(1));
        }
System.out.println("-------------------------------------------------------------------------------------");
       
   con.close();      
     
    }



public static void ttable(Connection con,Scanner scan) throws Exception
{

 String str;
do{
    System.out.println("enter day ( enter 1st 3 letter) ");
	 str=scan.next();
 	str= str.trim();
	str= str.toLowerCase();
 }while(str.length()!=3);
 
  System.out.println("enter class number");
	int cls=scan.nextInt();

System.out.println("enter sem");
	int sem=scan.nextInt();
 
 Statement st= con.createStatement();
        ResultSet rs=st.executeQuery("select t.time ,s.title,f.fname from tt t, faculty f, subject s, assignment a where t.subcode=s.subcode and  f.fid=a.fid and a.subcode=s.subcode and t.day='"+str+"' and t.cno="+cls+" and a.sem="+sem+" order by day;");
System.out.println("----------------------------------------------------------------------------------------------------------------------");
System.out.println(sem + "th sem "+str+" time table  :");
System.out.println("-----------------------------------------------------------------------------------------------------------------------");
System.out.println("time "+"\t"+"                ||\t subject name"+"\t\t\t\t\t\t"+"||\t          f.name");
System.out.println("------------------------------------------------------------------------------------------------------------------------");
   
        while (rs.next())
        {
   
            System.out.print(rs.getString("t.time"));
	    System.out.print("\t||");
	    System.out.print(rs.getString("s.title"));
		System.out.print("\t\t\t"+"\t");
	    System.out.println("("+rs.getString("f.fname")+")");
        }
System.out.println("-------------------------------------------------------*************************----------------------------------------");
       
         con.close();
     
    }
       







public static void staffTime(Connection con ,Scanner scan) throws Exception
{

String day;
do{
    System.out.println("enter day ( enter 1st 3 letter) ");
	 day=scan.next();
 	 day= day.trim();
	day= day.toLowerCase();
 }while(day.length()!=3);


System.out.println("enter staff name ");

String ss=scan.next();
ss=ss.toUpperCase();
ss= ss.trim();
 System.out.println(ss+"'s working time:");


 Statement st= con.createStatement();
        ResultSet rs=st.executeQuery("select t.time,a.sem from faculty f,tt t ,assignment a where f.fid=a.fid and t.subcode=a.subcode and t.day='"+day+"' and f.fname='"+ss+"';");
System.out.println("----------------------------------------------------------------------------------------------------------------------");

System.out.println("-----------------------------------------------------------------------------------------------------------------------");
System.out.println("time \t\t");
System.out.println("------------------------------------------------------------------------------------------------------------------------");
   
        while (rs.next())
        {
   
            System.out.print(rs.getString("t.time"));
	    System.out.print("\t||");
	    System.out.println(rs.getInt("a.sem"));
        }
System.out.println("-------------------------------------------------------*************************----------------------------------------");
       
         con.close();
}
















public static void main(String args[])
{

int choice,select;





	Scanner scan = new Scanner(System.in);
//do{
System.out.println("1.display section\n2.input section");
System.out.println("enter section");

select=scan.nextInt();
try{
switch(select)
{

	


case 1:	

do{
        Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
Connection con=DriverManager.getConnection(url,"root","gurucharan");  


         
System.out.println("1.dept\n2.classes\n3.timetable\n4.staff times\n5.stafflist"); 
System.out.println("enter the choice");
choice=scan.nextInt();
switch(choice)
{
      			case 1: TableDept(con);


			break;

			case 2: TableClass(con,scan);
			
			break;
			case 3: ttable(con,scan);
			break;
			case 4: staffTime(con,scan);
			break;
			case 5: faculty(con,scan);
			
			
} }while(true);

			//break;
case 2: System.out.println("application under construction");
}

//}while(true);


}

catch(Exception e){
            
            System.out.println("error");
            


}
}













}
