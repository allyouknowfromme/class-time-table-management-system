import java.sql.*;
import javax.sql.*;
public class timetable

{
public static ResultSet faculty(String dcode)
{


dcode=dcode.trim();
dcode=dcode.toUpperCase();

try{
Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
Connection con=DriverManager.getConnection(url,"root","gurucharan");  

Statement st= con.createStatement();
        ResultSet rs=st.executeQuery("SELECT fid,fname,rank,place FROM faculty WHERE dcode='"+dcode+"';");
  





return rs;
}
catch(Exception e)
    {
    return null;
    }
    }
      


public static ResultSet TableClass(String dcode)
{
					dcode= dcode.trim();
					dcode= dcode.toUpperCase();
					try{
Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
Connection con=DriverManager.getConnection(url,"root","gurucharan");  
 Statement st= con.createStatement();
ResultSet rs=st.executeQuery("SELECT c.cno,c.sem from department d,class c WHERE c.dcode = d.dcode and d.dcode='"+dcode+"';");
return rs;
   /*
        while (rs.next())
        {
   
            System.out.print(rs.getInt(1));
	   // System.out.print("\t || \t");
	    System.out.println(rs.getInt("c.sem"));
        }
System.out.println("-------------------------------------------------------------------------------------");
       
   con.close();*/}catch(Exception e)
    {
    return null;
    }
    }
      









/*

public static ResultSet TableDept() throws Exception
{
Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
Connection con=DriverManager.getConnection(url,"root","gurucharan"); 
Statement st= con.createStatement();
ResultSet rs=st.executeQuery("SELECT * from department;");

   /*while (rs.next())
        {
   
            System.out.print(rs.getString(2));
	    //System.out.print("\t || \t");
	    System.out.println(rs.getString(1));
        }
System.out.println("-------------------------------------------------------------------------------------");
       
   con.close();      
     
    }*///return rs;
//}*/


public static ResultSet ttable(String day,int classnum,int sem)
{

  do{
	
 	day= day.trim();
	day= day.toLowerCase();
 }while(day.length()!=3);
 
 try{
  Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
Connection con=DriverManager.getConnection(url,"root","gurucharan"); 
	

 
 Statement st= con.createStatement();
        ResultSet rs=st.executeQuery("select t.time ,s.title,f.fname from tt t, faculty f, subject s, assignment a where t.subcode=s.subcode and  f.fid=a.fid and a.subcode=s.subcode and t.day='"+day+"' and t.cno="+classnum+" and a.sem="+sem);


return rs;
 
    }catch(Exception e)
    {
    return null;}
    }
       







public static ResultSet staffTime(String day,String staffname)
{


do{  
	// day=scan.next();

 	 day= day.trim();
	day= day.toLowerCase();
 }while(day.length()!=3);




staffname=staffname.toUpperCase();
staffname= staffname.trim();
 
try{

Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
Connection con=DriverManager.getConnection(url,"root","gurucharan"); 
 Statement st= con.createStatement();
        ResultSet rs=st.executeQuery("select t.time,a.sem from faculty f,tt t ,assignment a where f.fid=a.fid and t.subcode=a.subcode and t.day='"+day+"' and f.fname='"+staffname+"';");

   /*
        while (rs.next())
        {
   
            System.out.print(rs.getString("t.time"));
	    System.out.print("\t||");
	    System.out.println(rs.getInt("a.sem"));
        }
System.out.println("-------------------------------------------------------*************************----------------------------------------");
       
         con.close();*/
return  rs;
}
catch(Exception e)
    {
    return null;}
    }
       




public static int deletefaculty(String fid)
	{
		fid = fid.trim().toUpperCase();
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/timetable?useSSL=false";
     
			Connection con=DriverManager.getConnection(url,"root","gurucharan");
			Statement stmt = con.createStatement();
			
			int count=0;
			count = stmt.executeUpdate("DELETE FROM faculty WHERE fid='" + fid +"'");
			
			if(count > 0)
				return count;
			else
				return -1;	
			
		}catch(Exception e){ return -1; }
	
	}














 }

