import java.io.*;
import java.sql.*;
import javax.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ttableservlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)
       throws ServletException,IOException
       {
       
       
       
       RequestDispatcher  dispatch = getServletContext().getRequestDispatcher("/timetable.jsp");
       
       try{
       String day=(String) request.getParameter("day");
       
     
	int classnum = Integer.parseInt( request.getParameter("classnum"));
	int sem=Integer.parseInt(request.getParameter("sem"));
	
	ResultSet rs;
	
	 rs = timetable.ttable(day,classnum,sem);
	
	String res;
	if(rs==null)
	{
	dispatch.forward(request,response);
	}
	else
	{  
	request.setAttribute("res",rs);
	//response.sendRedirect("http:/localhost:8080/timetable.jsp");
	
	//dispatch=getServletContext().getRequestDispatcher("http://localhost:8080/timetable.jsp");
	
	dispatch.forward(request,response);
	
	}
	
		}catch(Exception e)
		
		{
		//System.out.println(e);
		dispatch.forward(request,response);
		}
		} 
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException
	{
	doGet(request,response);
	}
 } 
